import { Priority } from './enums/priority.enum';
import { Status } from './enums/status.enum';

export interface Tasks {
  id: number;
  title: string;
  description: string;
  status: Status;
  priority: Priority;
  assigneeId: number;
  creatorId: number;
  deadLine: string;
  completedAt: string | null;
  projectId: number | null;
}